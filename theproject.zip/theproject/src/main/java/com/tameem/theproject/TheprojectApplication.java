package com.tameem.theproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheprojectApplication.class, args);
	}

}

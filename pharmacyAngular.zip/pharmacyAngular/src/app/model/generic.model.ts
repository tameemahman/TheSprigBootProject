
export class Generic {

    id?: number;
    name?: string;
    description?: string

}
package com.tameem.theproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}

# full-stack-ecommerce-project
A full stack e-commerce project with Angular (frontend), Spring-boot and MySQL (backend)
